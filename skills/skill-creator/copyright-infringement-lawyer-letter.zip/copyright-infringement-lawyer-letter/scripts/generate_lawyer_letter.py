#!/usr/bin/env python3
"""
著作权侵权律师函生成器
Copyright Infringement Lawyer Letter Generator

支持闲鱼、抖音、小红书等平台的著作权侵权律师函自动生成
"""

import argparse
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

def load_template(platform):
    """加载对应平台的律师函模板"""
    template_path = Path(__file__).parent.parent / "assets" / "templates" / f"lawyer_letter_{platform}.docx"

    if not template_path.exists():
        # 如果没有专用模板，使用通用模板
        template_path = Path(__file__).parent.parent / "assets" / "templates" / "lawyer_letter_general.docx"

    if not template_path.exists():
        raise FileNotFoundError(f"未找到模板文件: {template_path}")

    return str(template_path)

def generate_letter_content(args):
    """生成律师函内容"""
    # 计算截止日期
    current_date = datetime.now()
    deadline_date = current_date + timedelta(hours=args.deadline)

    # 根据平台选择不同的法律条款和表述
    platform_config = {
        'xianyu': {
            'infringement_type': '擅自低价销售含有我方作品的商品',
            'platform_name': '闲鱼平台',
            'evidence_focus': '商品页面、交易记录、价格对比'
        },
        'douyin': {
            'infringement_type': '未经授权使用我方视频片段进行带货宣传',
            'platform_name': '抖音平台',
            'evidence_focus': '视频链接、发布时间、播放量、评论互动'
        },
        'xiaohongshu': {
            'infringement_type': '未经许可转载、抄袭我方图文内容',
            'platform_name': '小红书平台',
            'evidence_focus': '笔记链接、发布时间、点赞收藏数据'
        }
    }

    config = platform_config.get(args.platform, platform_config['general'])

    # 生成律师函内容（这里返回一个结构化的数据字典）
    content = {
        'law_firm': '江苏剑桥颐华律师事务所',
        'lawyer': '杨卫薪',
        'contact_phone': '15651787581',
        'case_number': f'（{current_date.year}）苏剑律函字第 号',
        'recipient': args.infringer,
        'platform': config['platform_name'],
        'client_info': args.client_info,
        'work_name': args.work,
        'creation_date': args.creation_date if hasattr(args, 'creation_date') and args.creation_date else '2024年',
        'infringement_type': config['infringement_type'],
        'infringement_description': args.description if hasattr(args, 'description') and args.description else f'在{config["platform_name"]}以账号名称"{args.infringer}"，{config["infringement_type"]}',
        'legal_basis': '《著作权法》第二条、第十条、第五十三条',
        'deadline_hours': args.deadline,
        'deadline_date': deadline_date.strftime('%Y 年 %m 月 %d 日'),
        'claim_amount': args.claim_amount,
        'additional_requirements': args.requirements if hasattr(args, 'requirements') and args.requirements else '',
        'evidence_focus': config['evidence_focus']
    }

    return content

def save_content_as_markdown(content, output_path):
    """将内容保存为Markdown格式（用于预览）"""
    md_content = f"""# 著作权侵权律师函

**律师事务所：** {content['law_firm']}
**承办律师：** {content['lawyer']}
**联系电话：** {content['contact_phone']}

---

**{content['case_number']}**

**致 {content['recipient']}：**

{content['law_firm']}是依据中华人民共和国法律设立的合法律师事务所，经{content['client_info']}（以下简称"我方"）授权，现就贵方未经授权使用我方享有著作权的作品事宜，指派{content['lawyer']}律师致函如下：

## 一、著作权权属声明

我方于{content['creation_date']}创作完成作品《{content['work_name']}》，并在相关平台进行发布和销售。

根据{content['legal_basis']}的规定，我方自作品创作完成之日起即享有包括署名权、复制权、信息网络传播权在内的完整著作权。

## 二、贵方侵权事实

经查证，贵方在{content['platform']}{content['infringence_description']}，导致我方遭受了直接经济损失。

## 三、法律后果及我方要求

根据《著作权法》第五十三条及相关规定，贵方行为已涉嫌侵犯我方复制权、信息网络传播权，现要求如下：

**1.收到本函 {content['deadline_hours']} 小时内删除所有侵权内容，下架相关产品；**

**2.赔偿我方经济损失及维权合理开支人民币 {content['claim_amount']} 元。**

请贵方慎重对待此事，并于 {content['deadline_date']} 前通过以下方式联系我方协商解决。我方已对贵方的侵权行为进行公证取证，若贵方未按要求履行及赔偿，我方将采取包括但不限于平台投诉、行政举报、民事诉讼及刑事追责等维权措施。

特此函告！

{content['law_firm']}

律师：_______________

电话：{content['contact_phone']}（微信同号）

年 月 日

附：我方创作及贵方侵权证据
"""

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(md_content)

def main():
    parser = argparse.ArgumentParser(description='著作权侵权律师函生成器')

    # 必需参数
    parser.add_argument('--platform', required=True,
                       choices=['xianyu', 'douyin', 'xiaohongshu', 'general'],
                       help='侵权平台')
    parser.add_argument('--client_info', required=True,
                       help='我方当事人信息（姓名、平台账号等）')
    parser.add_argument('--work', required=True,
                       help='被侵权作品名称')
    parser.add_argument('--infringer', required=True,
                       help='侵权方信息（用户名/店铺名）')
    parser.add_argument('--claim_amount', type=int, required=True,
                       help='索赔金额（人民币）')
    parser.add_argument('--deadline', type=int, default=48,
                       help='整改期限（小时，默认48小时）')

    # 可选参数
    parser.add_argument('--creation_date',
                       help='作品创作完成日期')
    parser.add_argument('--description',
                       help='侵权事实详细描述')
    parser.add_argument('--requirements',
                       help='其他要求（如道歉声明等）')
    parser.add_argument('--output', default='律师函_生成版.docx',
                       help='输出文件名（默认：律师函_生成版.docx）')

    args = parser.parse_args()

    try:
        # 检查模板文件是否存在
        template_path = load_template(args.platform)
        print(f"✓ 使用模板: {template_path}")

        # 生成律师函内容
        content = generate_letter_content(args)
        print("✓ 律师函内容生成完成")

        # 保存预览版本
        preview_path = args.output.replace('.docx', '_预览.md')
        save_content_as_markdown(content, preview_path)
        print(f"✓ 预览文件已保存: {preview_path}")

        print(f"\n下一步：")
        print(f"1. 查看预览文件: {preview_path}")
        print(f"2. 使用模板文件生成最终Word文档: {template_path}")
        print(f"3. 添加相关证据附件")

    except Exception as e:
        print(f"✗ 生成失败: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()