---
name: copyright-infringement-lawyer-letter
description: This skill should be used when users need to generate professional copyright infringement lawyer letters for platforms like Xianyu (闲鱼), Douyin (抖音), Xiaohongshu (小红书), or other online platforms. It handles the complete workflow from collecting infringement details to generating a formal legal warning letter with proper legal citations and structured formatting.
---

# 著作权侵权律师函生成器

## Overview

本技能为律师事务所和法律从业者提供专业的著作权侵权律师函生成服务，支持多种在线平台的侵权案件处理。

## 快速开始

根据侵权平台和具体情况选择相应的处理流程：

- **闲鱼平台侵权**：使用闲鱼专用模板和流程
- **抖音平台侵权**：使用抖音专用模板和流程
- **小红书平台侵权**：使用小红书专用模板和流程
- **其他平台侵权**：使用通用模板和流程

## 律师函生成流程

### 第一步：收集侵权信息

收集以下必要信息：
- **我方当事人信息**：姓名/公司名、平台账号、联系方式
- **被侵权作品信息**：作品名称、创作完成日期、首次发布日期、平台链接
- **侵权方信息**：平台用户名/店铺名、侵权商品/内容链接
- **侵权事实**：具体侵权行为描述、开始时间、造成的损失
- **索赔要求**：赔偿金额、道歉要求、整改期限

### 第二步：选择平台模板

根据侵权平台选择对应的律师函模板：
- `assets/templates/lawyer_letter_xianyu.docx` - 闲鱼平台专用
- `assets/templates/lawyer_letter_douyin.docx` - 抖音平台专用
- `assets/templates/lawyer_letter_xiaohongshu.docx` - 小红书平台专用
- `assets/templates/lawyer_letter_general.docx` - 通用模板

### 第三步：生成律师函

使用 `scripts/generate_lawyer_letter.py` 脚本生成正式律师函：

```python
python3 scripts/generate_lawyer_letter.py \
  --platform xianyu \
  --client_info "成亚君，小红书：奇怪耶耶" \
  --work "2025年上高中语文教资科三新题型56篇" \
  --infringer "小耳朵甜饼" \
  --claim_amount 3000 \
  --deadline 48 \
  --output "律师函_生成版.docx"
```

### 第四步：添加证据附件

将相关证据文件添加到律师函附件中：
- 创作完成证明截图
- 首次发布记录
- 侵权行为截图（已公证）
- 损失统计证明

## 法律依据库

本技能包含完整的著作权法相关条款：

### 核心法律条文
- **《著作权法》第二条**：著作权保护范围
- **《著作权法》第十条**：著作权内容
- **《著作权法》第四十四条**：邻接权保护
- **《著作权法》第五十三条**：侵权法律责任

### 平台相关规定
- **《电子商务法》第四十一条**：平台知识产权保护义务
- **《信息网络传播权保护条例》**：网络侵权处理规定
- 各平台知识产权保护政策（详见参考资料）

## 各平台处理特点

### 闲鱼平台
- 侵权形式：低价销售盗版商品
- 重点：商品链接、价格对比、销售数量
- 证据收集：商品页面截图、交易记录

### 抖音平台
- 侵权形式：视频片段盗用、背景音乐侵权
- 重点：视频链接、发布时间、播放量
- 证据收集：视频录制、评论互动截图

### 小红书平台
- 侵权形式：图文内容抄袭、笔记搬运
- 重点：笔记链接、发布时间、点赞收藏数据
- 证据收集：笔记截图、数据对比

## 律师函格式规范

### 必要要素
1. **律师事务所抬头**
2. **案件编号格式**：（年份）苏剑律函字第 号
3. **致送对象**：明确侵权主体信息
4. **著作权权属声明**：创作完成时间、首次发布证明
5. **侵权事实陈述**：具体侵权行为描述
6. **法律依据引用**：准确引用相关法条
7. **维权要求**：明确的时间限制和赔偿要求
8. **联系方式**：律师联系方式和协商期限
9. **证据附件**：相关证明材料

### 格式要求
- 使用正式的法律文书格式
- 下划线标注关键信息（姓名、金额、期限等）
- 专业、严谨的法律用语
- 完整的律师事务所落款和律师签名

## Resources

This skill includes example resource directories that demonstrate how to organize different types of bundled resources:

### scripts/
Executable code (Python/Bash/etc.) that can be run directly to perform specific operations.

**Examples from other skills:**
- PDF skill: `fill_fillable_fields.py`, `extract_form_field_info.py` - utilities for PDF manipulation
- DOCX skill: `document.py`, `utilities.py` - Python modules for document processing

**Appropriate for:** Python scripts, shell scripts, or any executable code that performs automation, data processing, or specific operations.

**Note:** Scripts may be executed without loading into context, but can still be read by Claude for patching or environment adjustments.

### references/
Documentation and reference material intended to be loaded into context to inform Claude's process and thinking.

**Examples from other skills:**
- Product management: `communication.md`, `context_building.md` - detailed workflow guides
- BigQuery: API reference documentation and query examples
- Finance: Schema documentation, company policies

**Appropriate for:** In-depth documentation, API references, database schemas, comprehensive guides, or any detailed information that Claude should reference while working.

### assets/
Files not intended to be loaded into context, but rather used within the output Claude produces.

**Examples from other skills:**
- Brand styling: PowerPoint template files (.pptx), logo files
- Frontend builder: HTML/React boilerplate project directories
- Typography: Font files (.ttf, .woff2)

**Appropriate for:** Templates, boilerplate code, document templates, images, icons, fonts, or any files meant to be copied or used in the final output.

---

**Any unneeded directories can be deleted.** Not every skill requires all three types of resources.
